export interface Publisher {
  publisherName: string;
  location?: string;
  phoneNumber: number;
}
