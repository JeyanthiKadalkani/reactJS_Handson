import { takeEvery, put, takeLatest, delay } from "redux-saga/effects";

function* addItemAsync() {
  // yield delay(2000);
  yield put({ type: "ADD_ITEM_ASYNC", value: 1 });
  const users = yield fetch("https://jsonplaceholder.typicode.com/users").then(
    resp => resp.json()
  );
  yield put({ type: "FETCH_USER_ASYNC", list: users });
}
function* watchItems() {
  yield takeLatest("ADD_ITEM", addItemAsync);
}

export default watchItems;
