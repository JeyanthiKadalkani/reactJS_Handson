import React from "react";
import logo from "./logo.svg";
import "./App.css";
import ShowProduct from "./ShowProduct/ShowProduct.react";
function App() {
  return (
    <div className="App">
      <ShowProduct />
    </div>
  );
}

export default App;
