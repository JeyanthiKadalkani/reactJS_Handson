import React from "react";
import { connect } from "react-redux";
const ShowProduct = props => {
  return (
    <div>
      <p>{props.users[0].name}</p>
      <p>Quantity{props.count}</p>
      <button onClick={props.increment}>+</button>
      <button onClick={props.decrement}>-</button>
    </div>
  );
};

const mapStateToProps = state => {
  return {
    count: state.itemCount,
    users: state.users
  };
};

const mapDispatchToProps = dispatch => {
  return {
    increment: () => {
      dispatch({ type: "ADD_ITEM" });
    },
    decrement: () => {
      dispatch({ type: "SUB_ITEM" });
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ShowProduct);
