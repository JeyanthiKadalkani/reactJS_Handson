import React from "react";
import logo from "./logo.svg";
import "./App.css";
import ShowMessage from "./ShowMessage";
import Message from "./HandleMessage";
import { Item, Product } from "./HandleMessage";

const prod: Product = {
  productCode: 101,
  productName: "TV"
};
const App: React.FC = () => {
  return (
    <div className="App">
      <ShowMessage greeter={"Jeyanthi"} greeting={"hello"} />
      <Message product={prod} />
    </div>
  );
};

export default App;
