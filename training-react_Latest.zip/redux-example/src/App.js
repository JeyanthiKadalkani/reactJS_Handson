import React from "react";
import "./App.css";
import Greeter from "./Greeter/Greeter.react";
import ShowTrainers from "./ShowTrainers/ShowTrainers.react";
function App() {
  return (
    <div className="App">
      Hello
      {/* <Greeter /> */}
      <ShowTrainers />
    </div>
  );
}

export default App;
