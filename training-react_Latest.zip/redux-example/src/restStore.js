import { createStore } from "redux";
import { applyMiddleware } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import axios from "axios";
import thunk from "redux-thunk";
const initialState = {
  loaded: false,
  list: [{}]
};
//action creator
export const fetchTrainer = list => {
  return {
    type: "FETCH_TRAINERS",
    list: list,
    loaded: false
  };
};
const url = "http://localhost:4000/calendar";
// create a Funtion for thunk
export const fetchAllTrainers = () => {
  return function(dispatch) {
    axios
      .get(url)
      .then(resp =>
        dispatch({ type: "FETCH_TRAINERS", list: resp.data, loaded: true })
      );
  };
};
//Reducer
const trainers = (state = initialState, action) => {
  switch (action.type) {
    case "FETCH_TRAINERS":
      return action;

    default:
      return state;
  }
};

//store
const restStore = createStore(
  trainers,
  composeWithDevTools(applyMiddleware(thunk))
);
export default restStore;
