import React from "react";
import { connect } from "react-redux";

const Greeter = props => {
  return (
    <div>
      {props.txtmsg}
      <button onClick={props.birthday}>Birthday</button>
      <button onClick={props.anniversary}>Anniversary</button>
    </div>
  );
};

function mapStateToProps(state) {
  return {
    txtmsg: state.text
  };
}

const mapDispatchToProps = dispatch => {
  return {
    birthday: () => {
      dispatch({ type: "BIRTHDAY", text: "Happy Birthday" });
    },
    anniversary: () => {
      dispatch({ type: "ANNRVERSARY", text: "Happy Anniversary" });
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Greeter);
