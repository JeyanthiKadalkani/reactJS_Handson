import React from "react";

import Footer from "../Footer/Footer.react";
import Content from "../Content/Content.react";

class AdminDashboard extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="row">
        {/* <div className="col-md-3">
          <Header designer="Jeyanthi" />
        </div> */}
        <div className="col-md-6">
          <Content />
        </div>
        <div className="col-md-3">
          <Footer />
        </div>
      </div>
    );
  }
}

export default AdminDashboard;
