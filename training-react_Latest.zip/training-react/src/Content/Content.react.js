import React from "react";
import Chart from "react-google-charts";
const columns = [
  { type: "string", label: "Subject" },
  { type: "number", label: "2017-18" },
  { type: "number", label: "2018-19" }
];
const rows = [["java", 2000, 1000], ["AngJs", 3000, 5000]];
const data = [columns, ...rows];
const Content = () => {
  return (
    <div>
      Content
      <Chart chartType="BarChart" data={data} />
    </div>
  );
};

export default Content;
