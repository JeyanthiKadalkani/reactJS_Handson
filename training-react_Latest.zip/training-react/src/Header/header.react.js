import React from "react";
import logo from "../Images/Jellyfish.jpg";
import NavBar from "../NavBar/NavBar.react";

const Header = props => {
  return (
    <div>
      <NavBar />
      <img src={logo} alt="logo" width="50px" height="50px" />
      <p>Learning ReactJS {props.designer}</p>
    </div>
  );
};

export default Header;
