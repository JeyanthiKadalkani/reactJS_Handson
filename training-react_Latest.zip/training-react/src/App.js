import React from "react";
// import TrainingDashboard from "./TrainingDashboard/TrainingDashboard.react";
import MyRoutes from "./MyRoutes/MyRoutes.react";
import "./App.css";
import Header from "./Header/header.react";
// import AdminDashboard from "./AdminDashboard/AdminDashboard.react";
// import dp from "./Images/Jellyfish.jpg";
// import Profile from "./Profile/Profile.react";
// import ShowCourse from "./ShowCourse/ShowCourse.react";
function App() {
  // const user = {
  //   userName: "Raesh",
  //   email: "abc.com"
  // };
  return (
    <div className="App">
      <Header designer="Jeyanthi" />
      <MyRoutes />
      {/* <header className="App-header">
        <AdminDashboard />
        <Profile imgRef={dp} level={3} points={4} user={user} />
        <ShowCourse />
        <TrainingDashboard />
      </header> */}
    </div>
  );
}

export default App;
