import React from "react";
import { Route, Switch } from "react-router-dom";
import TrainingDashboard from "../TrainingDashboard/TrainingDashboard.react";
import AdminDashboard from "../AdminDashboard/AdminDashboard.react";
import dp from "../Images/Jellyfish.jpg";
import Profile from "../Profile/Profile.react";
import ShowCourse from "../ShowCourse/ShowCourse.react";
const user = {
  userName: "Raesh",
  email: "abc.com"
};
const MyRoutes = () => {
  return (
    <div>
      <Switch>
        <Route exact path="/" component={AdminDashboard} />
        <Route path="/admin" component={TrainingDashboard} />
        <Route path="/show" component={ShowCourse} />
        <Route
          path="/profile"
          render={() => {
            return <Profile imgRef={dp} points={5} level={3} user={user} />;
          }}
        />
      </Switch>
    </div>
  );
};

export default MyRoutes;
