import React from "react";

const Footer = () => {
  return (
    <div>
      <p>CopyRight</p>
    </div>
  );
};

export default Footer;
