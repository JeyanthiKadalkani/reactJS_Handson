import React from "react";
import DataTable from "../DataTable/DataTable.react";
import AddToCalendar from "../AddToCalendar/AddToCalendar.react";
class TrainingDashboard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      trngList: []
    };
  }

  url = "http://localhost:4000/calendar";
  componentDidMount() {
    fetch(this.url)
      .then(res => res.json())
      .then(data => this.setState({ trngList: data }));
  }
  render() {
    return (
      <React-Fragment>
        <AddToCalendar />
        <table className="table table-striped">
          <thead>
            <tr>
              <th>CourseName</th>
              <th>Duration</th>
            </tr>
          </thead>
          <tbody>
            <DataTable data={this.state.trngList} />
          </tbody>
        </table>{" "}
      </React-Fragment>
    );
  }
}

export default TrainingDashboard;
