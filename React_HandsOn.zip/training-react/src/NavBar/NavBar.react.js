import React from "react";
import { Link } from "react-router-dom";

const NavBar = () => {
  return (
    <nav>
      <ul>
        <li>
          <Link exact to="/">
            Admin
          </Link>
        </li>
        <li>
          <Link to="/admin">Training</Link>
        </li>
        <li>
          <Link to="/profile">Profile</Link>
        </li>
        <li>
          <Link to="/show">Show Course</Link>
        </li>
      </ul>
    </nav>
  );
};

export default NavBar;
