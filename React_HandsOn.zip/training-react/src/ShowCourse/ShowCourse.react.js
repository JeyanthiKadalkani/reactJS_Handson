import React from "react";
import Poll from "../Poll/Poll.react";

class ShowCourse extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      interested: 1,
      notNow: 0
    };
  }
  increment = () => {
    this.setState({ interested: this.state.interested + 1 });
  };
  update = (state, props) => {
    if (state.notNow > 10) {
      return null;
    } else {
      return { notNow: state.notNow + 1 };
    }
  };
  notNow = () => {
    this.setState(this.update);
    this.setState(this.update);
  };
  render() {
    return (
      <div>
        <p>Interested</p>
        <span>{this.state.interested}</span>
        <p>Not Interested</p>
        <span>{this.state.notNow}</span>
        <Poll action={this.increment} text={"Interested"} />
        <Poll action={this.notNow} text={"Not Interested"} />
      </div>
    );
  }
}

export default ShowCourse;
