import React from "react";

const DataTable = props => {
  return props.data.map((eachValue, idx) => {
    return (
      <tr key={eachValue.id}>
        <td>{eachValue.courseName}</td>
        <td>{eachValue.duration}</td>
      </tr>
    );
  });
};

export default DataTable;
