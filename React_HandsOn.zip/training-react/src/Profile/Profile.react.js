import React from "react";
import PropTypes from "prop-types";

const Profile = props => {
  return (
    <div>
      <img src={props.imgRef} alt="img" width="20px" height="20px" />
      <p>Points Earned {props.points}</p>
      <p>Level {props.level}</p>
      <p>{props.user.userName}</p>
      <p>{props.user.email}</p>
    </div>
  );
};
Profile.propTypes = {
  imgRef: PropTypes.string.isRequired,
  points: PropTypes.number,
  level: PropTypes.number,
  user: PropTypes.shape({
    userName: PropTypes.string,
    email: PropTypes.string
  })
};
export default Profile;
