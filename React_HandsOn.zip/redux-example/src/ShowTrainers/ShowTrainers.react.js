import React from "react";
import { connect } from "react-redux";
import { fetchAllTrainers } from "../restStore";
const ShowTrainers = props => {
  if (!props.loadStatus) {
    return (
      <div>
        <button onClick={props.get}>Show Trainers</button>
      </div>
    );
  } else {
    return props.dataList.map(val => {
      return (
        <div key={val.id}>
          <p>{val.courseName}</p>
        </div>
      );
    });
  }
};
function mapStateToProps(state) {
  return {
    loadStatus: state.loaded,
    dataList: state.list
  };
}

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    get: () => {
      dispatch(fetchAllTrainers());
    }
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ShowTrainers);
